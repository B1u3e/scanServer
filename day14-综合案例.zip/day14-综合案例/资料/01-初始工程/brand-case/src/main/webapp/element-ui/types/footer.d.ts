import { ElementUIComponent } from './component'

/** Footer Component */
export declare class ElFooter extends ElementUIComponent {
  /** Height of the footer */
  height: string
}
