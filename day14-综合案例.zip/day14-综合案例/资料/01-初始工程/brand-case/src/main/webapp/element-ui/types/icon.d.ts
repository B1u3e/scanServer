import { ElementUIComponent } from './component'

/** Icon Component */
export declare class ElIcon extends ElementUIComponent {
  /** Icon name */
  name: string  
}
